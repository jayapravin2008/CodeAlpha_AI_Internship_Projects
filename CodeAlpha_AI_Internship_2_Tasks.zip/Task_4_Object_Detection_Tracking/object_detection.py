import argparse
import cv2
from ultralytics import YOLO

def run(source, output="output.mp4", confidence=0.35):
    model = YOLO("yolo11n.pt")
    cap = cv2.VideoCapture(0 if source == "webcam" else source)
    if not cap.isOpened():
        raise RuntimeError("Could not open the selected video source.")

    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 640
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 480
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 1:
        fps = 25

    writer = cv2.VideoWriter(
        output, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
    )

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        results = model.track(frame, persist=True, conf=confidence, verbose=False)
        annotated = results[0].plot()

        # YOLO tracking IDs are included when available.
        writer.write(annotated)
        cv2.imshow("CodeAlpha - Object Detection & Tracking", annotated)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break

    cap.release()
    writer.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="webcam",
                        help="Use 'webcam' or path to a video file")
    parser.add_argument("--output", default="output.mp4")
    parser.add_argument("--confidence", type=float, default=0.35)
    args = parser.parse_args()
    run(args.source, args.output, args.confidence)
