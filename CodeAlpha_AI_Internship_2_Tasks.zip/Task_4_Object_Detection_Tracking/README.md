# CodeAlpha Task 4 – Object Detection and Tracking

Real-time object detection and tracking using OpenCV and a pretrained YOLO model.

## Technologies
- Python
- OpenCV
- Ultralytics YOLO
- Object tracking

## Run
```bash
pip install -r requirements.txt
python object_detection.py --source webcam
```

Press **q** to stop.

For a video file:
```bash
python object_detection.py --source input.mp4
```

The program detects objects, draws bounding boxes and uses YOLO tracking so detected objects can have persistent tracking IDs across frames. The pretrained model is downloaded by Ultralytics on first use if it is not already available locally.
