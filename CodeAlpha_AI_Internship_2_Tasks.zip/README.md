# CodeAlpha AI Internship – Completed Tasks

Completed two tasks from the provided CodeAlpha Artificial Intelligence task list:

1. **Task 2 – Chatbot for FAQs**
2. **Task 4 – Object Detection and Tracking**

Both projects include source code, README files and requirements files.

## GitHub repositories
Use the required CodeAlpha naming format:
- `CodeAlpha_FAQChatbot`
- `CodeAlpha_ObjectDetectionTracking`
