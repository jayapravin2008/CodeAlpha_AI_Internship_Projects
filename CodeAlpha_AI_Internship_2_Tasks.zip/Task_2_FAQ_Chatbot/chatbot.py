from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def build_engine(faqs):
    questions = [item["question"] for item in faqs]
    vectorizer = TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(questions)
    return vectorizer, matrix

def get_answer(user_question, faqs, threshold=0.18):
    vectorizer, matrix = build_engine(faqs)
    query = vectorizer.transform([user_question])
    similarities = cosine_similarity(query, matrix)[0]
    best_index = similarities.argmax()
    best_score = float(similarities[best_index])
    if best_score < threshold:
        return ("Sorry, I couldn't find a close FAQ match. Please try asking in a different way.", best_score)
    return faqs[best_index]["answer"], best_score
