FAQS = [
    {"question": "What is CodeAlpha?", "answer": "CodeAlpha is a software development company that offers internship opportunities and projects in emerging technologies."},
    {"question": "How do I complete my internship tasks?", "answer": "Complete the required tasks, upload the source code to GitHub, post a project explanation on LinkedIn, and submit the completed work through the provided submission form."},
    {"question": "Where should I upload my source code?", "answer": "Upload the complete source code to a GitHub repository named CodeAlpha_ProjectName."},
    {"question": "How many tasks should I complete?", "answer": "According to the internship instructions, you need to complete a minimum of two or three tasks depending on the assigned requirement."},
    {"question": "What is a completion certificate?", "answer": "The internship provides a completion certificate, described in the instructions as QR verified."},
    {"question": "Can I use NLP for the chatbot?", "answer": "Yes. The task specifically suggests NLP libraries such as NLTK or SpaCy and similarity methods such as cosine similarity."},
    {"question": "What is object detection?", "answer": "Object detection identifies objects in images or video and draws bounding boxes with labels around detected objects."},
    {"question": "Which models can be used for object detection?", "answer": "The task suggests pretrained models such as YOLO or Faster R-CNN."},
    {"question": "What is the internship website?", "answer": "The instructions list www.codealpha.tech as the CodeAlpha website."},
    {"question": "How can I contact CodeAlpha?", "answer": "The instructions list services@codealpha.tech and services.codealpha@gmail.com as email contacts."}
]
