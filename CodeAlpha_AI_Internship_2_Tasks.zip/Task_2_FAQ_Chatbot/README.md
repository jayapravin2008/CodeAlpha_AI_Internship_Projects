# CodeAlpha Task 2 – Chatbot for FAQs

A simple NLP FAQ chatbot that matches a user's question with the most similar FAQ using TF-IDF vectors and cosine similarity.

## Technologies
- Python
- Flask
- Scikit-learn
- TF-IDF
- Cosine similarity
- HTML/CSS/JavaScript

## Run
```bash
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5000` in your browser.

## Workflow
1. User enters a question.
2. The question is converted into TF-IDF features.
3. Cosine similarity compares it with the FAQ questions.
4. The highest-scoring FAQ answer is returned.
5. A threshold prevents unrelated questions from receiving a misleading answer.
