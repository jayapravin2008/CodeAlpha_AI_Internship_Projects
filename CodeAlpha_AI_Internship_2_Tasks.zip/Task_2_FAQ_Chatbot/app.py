from flask import Flask, render_template, request, jsonify
from faq_data import FAQS
from chatbot import get_answer

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.post("/ask")
def ask():
    data = request.get_json()
    question = data.get("question", "").strip()
    if not question:
        return jsonify({"answer": "Please enter a question.", "score": 0})
    answer, score = get_answer(question, FAQS)
    return jsonify({"answer": answer, "score": round(score, 2)})

if __name__ == "__main__":
    app.run(debug=True)
